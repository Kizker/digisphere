const blog_data = [
  {
    id: 1,
    img: "/assets/img/blog/blog_post01.jpg",
    user: "Artwork",
    date: "28 Sept 2023",
    comments: "3",
    title: "Minimal workspace for inspiration",
    desc: "Repellendus quasi sapiente dolorem veniam corporis cumque laboriosam nisi eaque earum, soluta ex nemo rerum velit. consequatur amet aliquam nesciunt nemo, deserunt facilis. Duis aute irure dolor voluptate velit esse cillum dolore fugiat nulla pariatur.",
  },
  {
    id: 2,
    img: "/assets/img/blog/blog_post02.jpg",
    user: "Artwork",
    date: "30 Oct 2023",
    comments: "5",
    title: "Delbo release NFT for Justice Charity",
    desc: "Repellendus quasi sapiente dolorem veniam corporis cumque laboriosam nisi eaque earum, soluta ex nemo rerum velit. consequatur amet aliquam nesciunt nemo, deserunt facilis. Duis aute irure dolor voluptate velit esse cillum dolore fugiat nulla pariatur.",
  },
  {
    id: 3,
    img: "/assets/img/blog/blog_post03.jpg",
    user: "Artwork",
    date: "25 Nov 2023",
    comments: "10",
    title: "Morning routine to boost your mood",
    desc: "Repellendus quasi sapiente dolorem veniam corporis cumque laboriosam nisi eaque earum, soluta ex nemo rerum velit. consequatur amet aliquam nesciunt nemo, deserunt facilis. Duis aute irure dolor voluptate velit esse cillum dolore fugiat nulla pariatur.",
  },
  {
    id: 4,
    img: "/assets/img/blog/blog_post04.jpg",
    user: "Artwork",
    date: "15 April 2023",
    comments: "12",
    title: "Wash Trading and safe trading practices guide",
    desc: "Repellendus quasi sapiente dolorem veniam corporis cumque laboriosam nisi eaque earum, soluta ex nemo rerum velit. consequatur amet aliquam nesciunt nemo, deserunt facilis. Duis aute irure dolor voluptate velit esse cillum dolore fugiat nulla pariatur.",
  },
]

export default blog_data
