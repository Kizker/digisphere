const collection_data = [
  {
    id:1,
    img:'/assets/img/artwork/06.jpg',
    name:'Metaverse',
    author:'TheSalvare'
  },
  {
    id:2,
    img:'/assets/img/artwork/07.jpg',
    name:'Polly Doll',
    author:'TheNative'
  },
  {
    id:3,
    img:'/assets/img/artwork/16.jpg',
    name:'Alec Art',
    author:'GeorgZvic'
  },
  {
    id:4,
    img:'/assets/img/artwork/11.jpg',
    name:'Toxic Poeth',
    author:'YazoiLup'
  },
  {
    id:5,
    img:'/assets/img/artwork/01.jpg',
    name:'Saphyre',
    author:'CryptoX'
  },
  {
    id:6,
    img:'/assets/img/artwork/13.jpg',
    name:'Charcuterie',
    author:'Texira'
  },
  {
    id:7,
    img:'/assets/img/artwork/12.jpg',
    name:'Paradise',
    author:'CryptoX'
  },
  {
    id:8,
    img:'/assets/img/artwork/10.jpg',
    name:'HighTown',
    author:'TheSalvare'
  },
]

export default collection_data;